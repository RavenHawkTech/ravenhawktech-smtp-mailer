<?php
/*
Plugin Name: RavenHawkTech SMTP Mailer
Description: Lightweight SMTP relay + diagnostics plugin for WordPress with verbose SMTP troubleshooting and sent mail logging.
Version: 1.0.5
Author: RavenHawkTech
*/

if (!defined('ABSPATH')) exit;

class RHT_SMTP_Mailer {
    const OPTION = 'rht_smtp_mailer';
    const LOG_OPTION = 'rht_smtp_mailer_log';

    public static function init() {
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('phpmailer_init', [__CLASS__, 'configure_phpmailer']);
        add_action('wp_mail_succeeded', [__CLASS__, 'log_mail_success']);
        add_action('wp_mail_failed', [__CLASS__, 'log_mail_failed']);
        add_action('admin_post_rht_smtp_test', [__CLASS__, 'handle_test']);
        add_action('admin_post_rht_smtp_clear_log', [__CLASS__, 'handle_clear_log']);
    }

    public static function defaults() {
        return [
            'enabled' => '0',
            'host' => '',
            'port' => '465',
            'port_preset' => '465',
            'encryption' => 'ssl',
            'auth_type' => 'login',
            'username' => '',
            'password' => '',
            'from_email' => get_option('admin_email'),
            'from_name' => get_bloginfo('name'),
            'timeout' => '15',
            'connection_timeout' => '5',
            'debug_level' => '2',
        ];
    }

    public static function options() {
        return wp_parse_args(get_option(self::OPTION, []), self::defaults());
    }

    public static function admin_menu() {
        global $admin_page_hooks;

        if (isset($admin_page_hooks['ravenhawktech'])) {
            add_submenu_page(
                'ravenhawktech',
                'RHT SMTP Mailer',
                'SMTP Mailer',
                'manage_options',
                'rht-smtp-mailer',
                [__CLASS__, 'settings_page']
            );
            return;
        }

        add_menu_page(
            'RavenHawkTech',
            'RavenHawkTech',
            'manage_options',
            'ravenhawktech',
            function () {
                echo '<div class="wrap"><h1>RavenHawkTech</h1><p>Select a module from the menu.</p></div>';
            },
            'dashicons-admin-generic',
            58
        );

        add_submenu_page(
            'ravenhawktech',
            'RHT SMTP Mailer',
            'SMTP Mailer',
            'manage_options',
            'rht-smtp-mailer',
            [__CLASS__, 'settings_page']
        );
    }

    public static function register_settings() {
        register_setting(self::OPTION, self::OPTION, [__CLASS__, 'sanitize']);
    }

    public static function sanitize($input) {
        $port_preset = sanitize_text_field($input['port_preset'] ?? '465');
        $port = ($port_preset === 'custom') ? absint($input['port'] ?? 465) : absint($port_preset);

        return [
            'enabled' => !empty($input['enabled']) ? '1' : '0',
            'host' => sanitize_text_field($input['host'] ?? ''),
            'port' => $port,
            'port_preset' => $port_preset,
            'encryption' => sanitize_key($input['encryption'] ?? 'ssl'),
            'auth_type' => sanitize_key($input['auth_type'] ?? 'login'),
            'username' => sanitize_text_field($input['username'] ?? ''),
            'password' => (string)($input['password'] ?? ''),
            'from_email' => sanitize_email($input['from_email'] ?? get_option('admin_email')),
            'from_name' => sanitize_text_field($input['from_name'] ?? get_bloginfo('name')),
            'timeout' => max(5, absint($input['timeout'] ?? 15)),
            'connection_timeout' => max(2, absint($input['connection_timeout'] ?? 5)),
            'debug_level' => absint($input['debug_level'] ?? 2),
        ];
    }

    public static function configure_phpmailer($phpmailer) {
        $o = self::options();

        if ($o['enabled'] !== '1') {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = $o['host'];
        $phpmailer->Port = (int)$o['port'];
        $phpmailer->SMTPAuth = true;
        $phpmailer->Username = $o['username'];
        $phpmailer->Password = $o['password'];
        $phpmailer->Timeout = (int)$o['timeout'];
        $phpmailer->Timelimit = (int)($o['connection_timeout'] ?? 5);

        if (($o['auth_type'] ?? 'login') === 'plain') {
            $phpmailer->AuthType = 'PLAIN';
        } elseif (($o['auth_type'] ?? 'login') === 'cram-md5') {
            $phpmailer->AuthType = 'CRAM-MD5';
        } else {
            $phpmailer->AuthType = 'LOGIN';
        }

        if ($o['encryption'] === 'ssl') {
            $phpmailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif ($o['encryption'] === 'tls') {
            $phpmailer->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $phpmailer->SMTPSecure = '';
            $phpmailer->SMTPAutoTLS = false;
        }

        $phpmailer->From = $o['from_email'];
        $phpmailer->FromName = $o['from_name'];
    }

    public static function add_log_entry($entry) {
        $log = get_option(self::LOG_OPTION, []);
        if (!is_array($log)) {
            $log = [];
        }

        array_unshift($log, wp_parse_args($entry, [
            'date' => current_time('mysql'),
            'to' => '',
            'subject' => '',
            'status' => 'unknown',
            'message' => '',
        ]));

        $log = array_slice($log, 0, 100);
        update_option(self::LOG_OPTION, $log, false);
    }

    public static function log_mail_success($mail_data) {
        $to = $mail_data['to'] ?? '';
        if (is_array($to)) {
            $to = implode(', ', $to);
        }

        self::add_log_entry([
            'to' => (string)$to,
            'subject' => (string)($mail_data['subject'] ?? ''),
            'status' => 'sent',
            'message' => 'wp_mail() reported successful delivery handoff.',
        ]);
    }

    public static function log_mail_failed($wp_error) {
        $data = is_wp_error($wp_error) ? $wp_error->get_error_data() : [];
        $to = $data['to'] ?? '';
        if (is_array($to)) {
            $to = implode(', ', $to);
        }

        self::add_log_entry([
            'to' => (string)$to,
            'subject' => (string)($data['subject'] ?? ''),
            'status' => 'failed',
            'message' => is_wp_error($wp_error) ? $wp_error->get_error_message() : 'Unknown mail failure.',
        ]);
    }

    public static function handle_clear_log() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }

        check_admin_referer('rht_smtp_clear_log');
        delete_option(self::LOG_OPTION);

        wp_safe_redirect(admin_url('admin.php?page=rht-smtp-mailer&tab=log'));
        exit;
    }

    public static function diagnostics($to_email = '', $mode = 'full') {
        $o = self::options();
        $log = [];
        $mode = sanitize_key($mode ?: 'full');

        $log[] = '=== RavenHawkTech SMTP Diagnostics ===';
        $log[] = 'Mode: ' . strtoupper($mode);
        $log[] = 'Host: ' . $o['host'];
        $log[] = 'Port: ' . $o['port'];
        $log[] = 'Encryption: ' . $o['encryption'];
        $log[] = 'Auth Type: ' . ($o['auth_type'] ?? 'login');

        if (empty($o['host'])) {
            $log[] = 'ERROR: SMTP host is empty.';
            return implode("\n", $log);
        }

        $dns = gethostbyname($o['host']);
        $log[] = ($dns === $o['host']) ? 'WARNING: DNS lookup may have failed.' : 'DNS resolved: ' . $dns;

        if ($mode === 'dns') {
            return implode("\n", $log);
        }

        $errno = 0;
        $errstr = '';
        $transport = ($o['encryption'] === 'ssl') ? 'ssl://' : '';
        $connect_timeout = max(2, (int)($o['connection_timeout'] ?? 5));

        $started = microtime(true);
        $socket = @fsockopen($transport . $o['host'], (int)$o['port'], $errno, $errstr, $connect_timeout);
        $elapsed = round(microtime(true) - $started, 2);

        if (!$socket) {
            $log[] = 'TCP CONNECTION FAILED after ' . $elapsed . ' seconds';
            $log[] = 'Error: ' . $errstr;
            $log[] = 'Code: ' . $errno;
            return implode("\n", $log);
        }

        $log[] = 'TCP connection successful in ' . $elapsed . ' seconds.';

        if ($mode === 'tcp') {
            fclose($socket);
            return implode("\n", $log);
        }

        stream_set_timeout($socket, $connect_timeout);
        $banner = fgets($socket, 2048);
        if ($banner) {
            $log[] = 'SMTP Banner: ' . trim($banner);
        }

        fwrite($socket, 'EHLO ' . parse_url(home_url(), PHP_URL_HOST) . "\r\n");
        $capabilities = '';
        while (($line = fgets($socket, 2048)) !== false) {
            $capabilities .= $line;
            if (preg_match('/^250\s/', $line)) {
                break;
            }
        }

        if ($capabilities) {
            $log[] = 'SMTP EHLO capabilities:';
            $log[] = trim($capabilities);
        }

        fwrite($socket, "QUIT\r\n");
        fclose($socket);

        if ($mode === 'handshake') {
            return implode("\n", $log);
        }

        if ($to_email) {
            $log[] = '';
            $log[] = 'Attempting test email to: ' . $to_email;

            add_action('phpmailer_init', function($phpmailer) use (&$log, $o) {
                $phpmailer->SMTPDebug = (int)$o['debug_level'];
                $phpmailer->Timeout = (int)$o['timeout'];
                $phpmailer->Timelimit = (int)($o['connection_timeout'] ?? 5);
                $phpmailer->Debugoutput = function($str, $level) use (&$log) {
                    $log[] = '[SMTP ' . $level . '] ' . $str;
                };
            }, 99);

            $sent = wp_mail(
                $to_email,
                'RavenHawkTech SMTP Test',
                'SMTP diagnostics test message.'
            );

            $log[] = $sent ? 'SUCCESS: wp_mail() succeeded.' : 'ERROR: wp_mail() failed.';
        } else {
            $log[] = 'No test email address provided, so full send was skipped.';
        }

        return implode("\n", $log);
    }

    public static function handle_test() {
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied.');
        }

        check_admin_referer('rht_smtp_test');

        $mode = sanitize_key($_POST['test_mode'] ?? 'full');
        $results = self::diagnostics(sanitize_email($_POST['test_email'] ?? ''), $mode);

        set_transient('rht_smtp_results', $results, 300);

        wp_safe_redirect(admin_url('admin.php?page=rht-smtp-mailer&tab=settings'));
        exit;
    }

    public static function settings_page() {
        $o = self::options();
        $results = get_transient('rht_smtp_results');
        delete_transient('rht_smtp_results');

        $tab = sanitize_key($_GET['tab'] ?? 'settings');
        if (!in_array($tab, ['settings', 'log'], true)) {
            $tab = 'settings';
        }

        $log = get_option(self::LOG_OPTION, []);
        if (!is_array($log)) {
            $log = [];
        }
?>
<div class="wrap rht-smtp-admin">
<div style="display:flex;align-items:center;gap:14px;margin-bottom:18px;padding:14px 18px;background:#111827;border-left:4px solid #dc2626;border-radius:10px;color:#f9fafb;">
<div style="font-size:28px;">📨</div>
<div>
<h1 style="margin:0;color:#fff;">RavenHawkTech SMTP Mailer</h1>
<p style="margin:4px 0 0;color:#d1d5db;">SMTP relay, diagnostics, and WordPress mail troubleshooting.</p>
</div>
</div>

<h2 class="nav-tab-wrapper">
    <a href="<?php echo esc_url(admin_url('admin.php?page=rht-smtp-mailer&tab=settings')); ?>" class="nav-tab <?php echo $tab === 'settings' ? 'nav-tab-active' : ''; ?>">SMTP Settings</a>
    <a href="<?php echo esc_url(admin_url('admin.php?page=rht-smtp-mailer&tab=log')); ?>" class="nav-tab <?php echo $tab === 'log' ? 'nav-tab-active' : ''; ?>">Sent Mail Log</a>
</h2>

<?php if ($tab === 'settings'): ?>

<form method="post" action="options.php">
<?php settings_fields(self::OPTION); ?>

<table class="form-table">
<tr><th>Enable SMTP</th><td><input type="checkbox" name="<?php echo esc_attr(self::OPTION); ?>[enabled]" value="1" <?php checked($o['enabled'], '1'); ?>></td></tr>
<tr><th>SMTP Host</th><td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[host]" value="<?php echo esc_attr($o['host']); ?>"></td></tr>

<tr>
<th>Port Preset</th>
<td>
<select id="rht-smtp-port-preset" name="<?php echo esc_attr(self::OPTION); ?>[port_preset]" onchange="rhtToggleCustomPort()">
<option value="465" <?php selected($o['port_preset'], '465'); ?>>465 (SSL/TLS)</option>
<option value="587" <?php selected($o['port_preset'], '587'); ?>>587 (STARTTLS)</option>
<option value="25" <?php selected($o['port_preset'], '25'); ?>>25 (Legacy SMTP)</option>
<option value="2525" <?php selected($o['port_preset'], '2525'); ?>>2525 (Alternate SMTP)</option>
<option value="custom" <?php selected($o['port_preset'], 'custom'); ?>>Custom</option>
</select>
<div id="rht-smtp-custom-port" style="<?php echo ($o['port_preset'] ?? '') === 'custom' ? '' : 'display:none;'; ?>margin-top:8px;">
<input type="number" name="<?php echo esc_attr(self::OPTION); ?>[port]" value="<?php echo esc_attr($o['port']); ?>" placeholder="Custom Port">
</div>
</td>
</tr>

<tr><th>Encryption</th>
<td>
<select name="<?php echo esc_attr(self::OPTION); ?>[encryption]">
<option value="none" <?php selected($o['encryption'], 'none'); ?>>None</option>
<option value="tls" <?php selected($o['encryption'], 'tls'); ?>>STARTTLS</option>
<option value="ssl" <?php selected($o['encryption'], 'ssl'); ?>>SSL/TLS</option>
</select>
</td>
</tr>

<tr>
<th>Authentication Type</th>
<td>
<select name="<?php echo esc_attr(self::OPTION); ?>[auth_type]">
<option value="login" <?php selected($o['auth_type'] ?? 'login', 'login'); ?>>LOGIN</option>
<option value="plain" <?php selected($o['auth_type'] ?? 'login', 'plain'); ?>>PLAIN</option>
<option value="cram-md5" <?php selected($o['auth_type'] ?? 'login', 'cram-md5'); ?>>CRAM-MD5</option>
</select>
<p class="description">Most providers use LOGIN. The diagnostics output shows which methods the server advertises.</p>
</td>
</tr>

<tr><th>Username</th><td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[username]" value="<?php echo esc_attr($o['username']); ?>"></td></tr>
<tr><th>Password</th><td><input type="password" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[password]" value="<?php echo esc_attr($o['password']); ?>"></td></tr>
<tr><th>From Email</th><td><input type="email" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[from_email]" value="<?php echo esc_attr($o['from_email']); ?>"></td></tr>
<tr><th>From Name</th><td><input type="text" class="regular-text" name="<?php echo esc_attr(self::OPTION); ?>[from_name]" value="<?php echo esc_attr($o['from_name']); ?>"></td></tr>
<tr><th>Mail Timeout</th><td><input type="number" name="<?php echo esc_attr(self::OPTION); ?>[timeout]" value="<?php echo esc_attr($o['timeout']); ?>"> seconds</td></tr>
<tr><th>Connection Timeout</th><td><input type="number" name="<?php echo esc_attr(self::OPTION); ?>[connection_timeout]" value="<?php echo esc_attr($o['connection_timeout']); ?>"> seconds</td></tr>

<tr>
<th>SMTP Debug Level</th>
<td>
<select name="<?php echo esc_attr(self::OPTION); ?>[debug_level]">
<option value="0" <?php selected($o['debug_level'], '0'); ?>>0 - Off</option>
<option value="1" <?php selected($o['debug_level'], '1'); ?>>1 - Client</option>
<option value="2" <?php selected($o['debug_level'], '2'); ?>>2 - Client + Server</option>
<option value="3" <?php selected($o['debug_level'], '3'); ?>>3 - Connection</option>
<option value="4" <?php selected($o['debug_level'], '4'); ?>>4 - Low-level</option>
</select>
</td>
</tr>
</table>

<?php submit_button('Save SMTP Settings'); ?>
</form>

<script>
function rhtToggleCustomPort() {
    var preset = document.getElementById('rht-smtp-port-preset');
    var custom = document.getElementById('rht-smtp-custom-port');
    if (!preset || !custom) return;
    custom.style.display = preset.value === 'custom' ? 'block' : 'none';
}
document.addEventListener('DOMContentLoaded', rhtToggleCustomPort);
</script>

<hr>

<h2>SMTP Diagnostics</h2>
<p>Select a quick test mode while troubleshooting. Use full send only when you want to send an actual email.</p>

<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
<?php wp_nonce_field('rht_smtp_test'); ?>
<input type="hidden" name="action" value="rht_smtp_test">

<p><input type="email" class="regular-text" name="test_email" placeholder="test@example.com"></p>

<p>
<select name="test_mode">
<option value="dns">DNS only - fastest</option>
<option value="tcp">TCP connect only</option>
<option value="handshake">SMTP handshake only</option>
<option value="full" selected>Full send test</option>
</select>
</p>

<?php submit_button('Run Selected SMTP Diagnostic', 'secondary'); ?>
</form>

<?php if ($results): ?>
<hr>
<h2>Diagnostics Results</h2>
<textarea readonly style="width:100%;min-height:420px;font-family:monospace;"><?php echo esc_textarea($results); ?></textarea>
<?php endif; ?>

<?php else: ?>

<h2>Sent Mail Log</h2>
<p>Shows the most recent 100 WordPress mail handoff attempts captured by this plugin.</p>

<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:12px;">
<?php wp_nonce_field('rht_smtp_clear_log'); ?>
<input type="hidden" name="action" value="rht_smtp_clear_log">
<?php submit_button('Clear Mail Log', 'delete', 'submit', false); ?>
</form>

<table class="widefat striped">
<thead>
<tr>
    <th>Date Sent</th>
    <th>Recipient</th>
    <th>Subject</th>
    <th>Status</th>
    <th>Message</th>
</tr>
</thead>
<tbody>
<?php if (!$log): ?>
<tr><td colspan="5">No mail log entries yet.</td></tr>
<?php else: ?>
<?php foreach ($log as $entry): ?>
<tr>
    <td><?php echo esc_html($entry['date'] ?? ''); ?></td>
    <td><?php echo esc_html($entry['to'] ?? ''); ?></td>
    <td><?php echo esc_html($entry['subject'] ?? ''); ?></td>
    <td>
        <?php
        $status = $entry['status'] ?? 'unknown';
        $color = $status === 'sent' ? '#15803d' : ($status === 'failed' ? '#b91c1c' : '#6b7280');
        ?>
        <strong style="color:<?php echo esc_attr($color); ?>"><?php echo esc_html(ucfirst($status)); ?></strong>
    </td>
    <td><?php echo esc_html($entry['message'] ?? ''); ?></td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>

<?php endif; ?>
</div>
<?php
    }
}

RHT_SMTP_Mailer::init();
