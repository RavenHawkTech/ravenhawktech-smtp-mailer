# RavenHawkTech SMTP Mailer

Version 1.0.5

Features:
- RavenHawkTech admin menu integration
- SMTP relay override for WordPress wp_mail()
- STARTTLS / SSL / None support
- LOGIN / PLAIN / CRAM-MD5 auth selector
- Port preset dropdown with custom port field
- DNS-only, TCP-only, SMTP handshake, and full send diagnostics
- Sent mail log tab
- Clear log action
